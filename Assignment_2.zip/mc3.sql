CREATE TABLE Designer (
    Designer_ID INT PRIMARY KEY,
    SSN VARCHAR(11) UNIQUE NOT NULL,
    FirstName VARCHAR(20),
    LastName VARCHAR(20)
);

CREATE TABLE Customer (
    CustomerID INT PRIMARY KEY,
    Name VARCHAR(40)
);

CREATE TABLE Telephone (
    CustomerID INT,
    PhoneNumber VARCHAR(20),
    PRIMARY KEY (CustomerID, PhoneNumber),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

CREATE TABLE Tailoring_Technician (
    SSN VARCHAR(11) PRIMARY KEY,
    FirstName VARCHAR(20),
    LastName VARCHAR(20)
);

CREATE TABLE Outfit (
    Outfit_ID INT PRIMARY KEY,
    Completion_Date DATE,
    Unreasonable_Price INT,
    Designer_ID INT,
    CustomerID INT,
    FOREIGN KEY (Designer_ID) REFERENCES Designer(Designer_ID),
    FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);

CREATE TABLE FashionShow (
    Show_ID INT PRIMARY KEY,
    Date DATE,
    Location VARCHAR(255)
);

CREATE TABLE Work_On (
    SSN VARCHAR(11),
    Outfit_ID INT,
    StartDate DATE,
    PRIMARY KEY (SSN, Outfit_ID),
    FOREIGN KEY (SSN) REFERENCES Tailoring_Technician(SSN),
    FOREIGN KEY (Outfit_ID) REFERENCES Outfit(Outfit_ID)
);

CREATE TABLE Feature (
    Designer_ID INT,
    Show_ID INT,
    PRIMARY KEY (Designer_ID, Show_ID),
    FOREIGN KEY (Designer_ID) REFERENCES Designer(Designer_ID),
    FOREIGN KEY (Show_ID) REFERENCES FashionShow(Show_ID)
);

--测试数据
INSERT INTO Designer (Designer_ID, SSN, FirstName, LastName) VALUES (1, 11111111111, "Yuxuan", "Sun");
INSERT INTO Designer (Designer_ID, SSN, FirstName, LastName) VALUES (2, 22222222222, "YuSun", "Xuan");
INSERT INTO Designer (Designer_ID, SSN, FirstName, LastName) VALUES (3, 12109050200, "SunYU", "Xuan");

INSERT INTO Customer (CustomerID, Name) VALUES (1, 'AMY');
INSERT INTO Customer (CustomerID, Name) VALUES (2, 'BEn');
INSERT INTO Customer (CustomerID, Name) VALUES (3, 'CHina');

INSERT INTO Telephone (CustomerID, PhoneNumber) VALUES (1, '1234567890');
INSERT INTO Telephone (CustomerID, PhoneNumber) VALUES (1, '2345678901');
INSERT INTO Telephone (CustomerID, PhoneNumber) VALUES (2, '3456789012');

INSERT INTO Tailoring_Technician (SSN, FirstName, LastName) VALUES ('111111111', 'David', 'Chen');
INSERT INTO Tailoring_Technician (SSN, FirstName, LastName) VALUES ('222222222', 'Emily', 'Xu');
INSERT INTO Tailoring_Technician (SSN, FirstName, LastName) VALUES ('333333333', 'Farry', 'He');

INSERT INTO Outfit (Outfit_ID, Completion_Date, Unreasonable_Price, Designer_ID, CustomerID) VALUES (1, '2023-11-02', 100000, 1, 1);
INSERT INTO Outfit (Outfit_ID, Completion_Date, Unreasonable_Price, Designer_ID, CustomerID) VALUES (2, '2023-11-03', 200000, 1, 2);
INSERT INTO Outfit (Outfit_ID, Completion_Date, Unreasonable_Price, Designer_ID, CustomerID) VALUES (3, '2023-01-01', 999999, 2, 3);

INSERT INTO FashionShow (Show_ID, Date, Location) VALUES (1, '2023-01-01', 'shenzhen');
INSERT INTO FashionShow (Show_ID, Date, Location) VALUES (2, '2023-02-01', 'longgang');
INSERT INTO FashionShow (Show_ID, Date, Location) VALUES (3, '2023-01-11', 'CUHKSZ');

INSERT INTO Work_On (SSN, Outfit_ID, StartDate) VALUES ('111111111', 1, '2022-01-01');
INSERT INTO Work_On (SSN, Outfit_ID, StartDate) VALUES ('222222222', 2, '2021-01-01');
INSERT INTO Work_On (SSN, Outfit_ID, StartDate) VALUES ('333333333', 3, '2020-01-01');

INSERT INTO Feature (Designer_ID, Show_ID) VALUES (1, 1);
INSERT INTO Feature (Designer_ID, Show_ID) VALUES (1, 2);
INSERT INTO Feature (Designer_ID, Show_ID) VALUES (2, 3);

--打印table
SELECT * FROM Designer;
SELECT * FROM Customer;
SELECT * FROM Tailoring_Technician;
SELECT * FROM Outfit;
SELECT * FROM feature;
SELECT * FROM telephone;
SELECT * FROM work_on;
SELECT * FROM fashionshow;

--检查外键约束
SELECT TABLE_NAME, COLUMN_NAME, CONSTRAINT_NAME, REFERENCED_TABLE_NAME, REFERENCED_COLUMN_NAME
FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE REFERENCED_TABLE_SCHEMA = 'student1'; 