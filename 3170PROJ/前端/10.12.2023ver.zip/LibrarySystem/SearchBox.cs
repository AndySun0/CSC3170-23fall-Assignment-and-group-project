﻿using System.Windows.Forms;

namespace LibrarySystem
{
    public partial class SearchBox : UserControl
    {
        public SearchBox()
        {
            InitializeComponent();
        }
    }
}
